//
//  ViewController.swift
//  UserAPIApp
//
//  Created by Junne Murdock on 2/27/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}


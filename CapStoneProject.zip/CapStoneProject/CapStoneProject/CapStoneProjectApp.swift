//
//  CapStoneProjectApp.swift
//  CapStoneProject
//
//  Created by Junne Murdock on 3/6/23.
//

import SwiftUI

@main
struct CapStoneProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
